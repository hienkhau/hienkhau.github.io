# Personal Data Analyst Project — Spotify & YouTube Dataset Analysis
## Project Overview
This project analyzes the spotify and youtube dataset to answer some questions
It demonstrates skills in **data cleaning, analysis, visualization**.

## Project Structure
*dataset* - Spotify Youtube Dataset.csv
*script* - P9 - Spotify Analysis.ipynb
